# Daisyxmusic (Telegram bot project )
# Copyright (C) 2021  Inukaasith

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.


from pyrogram import Client, filters
from pyrogram.errors import UserAlreadyParticipant

from DaisyXMusic.helpers.decorators import authorized_users_only, errors
from DaisyXMusic.services.callsmusic.callsmusic import client as USER


@Client.on_message(filters.command(["userjoin"]) & ~filters.private & ~filters.bot)
@authorized_users_only
@errors
async def addchannel(client, message):
    chid = message.chat.id
    try:
        invitelink = await client.export_chat_invite_link(chid)
    except:
        await message.reply_text(
            "<b>Əvvəlcə məni qrup admini kimi təyin edin</b>",
        )
        return

    try:
        user = await USER.get_me()
    except:
        user.first_name = "DTOMusic"

    try:
        await USER.join_chat(invitelink)
        await USER.send_message(message.chat.id, "İstədiyiniz kimi buraya qoşuldum")
    except UserAlreadyParticipant:
        await message.reply_text(
            "<b>Userbot Onsuzda Qrupunuzdadır</b>",
        )
    except Exception as e:
        print(e)
        await message.reply_text(
            f"<b>🛑 Daşqın Gözləmə Xətası 🛑 \n İstifadəçi {user.first_name}, istifadəçi üçün çoxlu qoşulma tələblərinə görə qrupunuza qoşula bilmədi! İstifadəçinin qrupda qadağan olunmadığından əmin olun.",
        )
        return
    await message.reply_text(
        "<b>köməkçi userbot söhbətinizə qatıldı</b>",
    )


@USER.on_message(filters.group & filters.command(["userleave"]))
async def rem(USER, message):
    try:
        await USER.leave_chat(message.chat.id)
    except:
        await message.reply_text(
            f"<b>İstifadəçi qrupunuzdan çıxa bilmədi! Daşqın ola bilər."
            "\n\nYa da məni Qrupunuza əl ilə vurun</b>",
        )
        return

# Daisyxmusic (Telegram bot project )
# Copyright (C) 2021  Inukaasith

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.


from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, Message


@Client.on_message(filters.command("start") & filters.private & ~filters.channel)
async def start(_, message: Message):
    await message.reply_text(
        f"""Salam! mən DTOMusicBot 🎵\nQrupunuzun səsli zəngində musiqi səsləndirə bilərəm.
        Botu Grupa Qatıb admin edin və daha sonra @DTOMusicassisstant qrupa qatin
        Məni qrupuna əlavə et və sərbəst musiqi çal!""",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "➕ Groupa əlavə et", url="https://t.me/DTOMusic_bot?startgroup=true")
                ],
                [
                    InlineKeyboardButton(
                        "🎛 Musiqi Qrupumuz", url="https://t.me/DTOmusicbotresmi1"),
                    InlineKeyboardButton(
                        "🖥 Rəsmi kanal", url="https://t.me/FTOmusicbotresmi")     
                ],[ 
                    InlineKeyboardButton(
                        "💡 Sahibim", url="t.me/BatyaBT"
                        )
                ]
            ]
        ),
        disable_web_page_preview=True,
    )


@Client.on_message(filters.command("start") & ~filters.private & ~filters.channel)
async def gstart(_, message: Message):
    await message.reply_text(
        """**Bot Onlayndır Kömək üçün adminə yazın**""",
        reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "💡 Sahibim", url="t.me/BatyaBT"
                    )
                ]
            ]
        ),
    )
